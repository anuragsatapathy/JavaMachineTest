package com.midvi.service;

import javax.ejb.Local;

@Local
public interface DataLoaderLocal {

}
