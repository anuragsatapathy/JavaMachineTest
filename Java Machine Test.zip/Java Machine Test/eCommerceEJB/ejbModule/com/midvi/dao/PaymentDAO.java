package com.midvi.dao;

import com.midvi.entity.Payment;

public interface PaymentDAO extends GenericDAO<Payment, Long>{

}
