package com.midvi.eventListener;

public enum Protocol {
    SMTP,
    SMTPS,
    TLS
}